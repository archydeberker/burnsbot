import os

print(os.environ.get('SLACK_BOT_TOKEN'))
print(os.environ.get('BOT_ID'))